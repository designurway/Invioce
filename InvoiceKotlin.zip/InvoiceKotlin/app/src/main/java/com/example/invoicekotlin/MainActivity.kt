package com.example.invoicekotlin

import android.app.ProgressDialog.show
import android.content.ContentValues.TAG
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.viewpager.widget.ViewPager
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.tabs.TabLayout

class MainActivity : AppCompatActivity() {
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<ConstraintLayout>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
       val  customBottomSheetDialogFragment = CustomBottomSheetDialogFragment()





      var one:Boolean=false
        val mobile_gst_tv = findViewById<TextView>(R.id.mobile_gst_tv)
        val pricing_tv = findViewById<TextView>(R.id.pricing_tv)
        val add_gst_tax_details_tv = findViewById<TextView>(R.id.add_gst_tax_details_tv)
        val card_view_cvvv = findViewById<CardView>(R.id.card_view_cvvv)


        val Add_items_btn = findViewById<Button>(R.id.Add_items_btn)


        val mobile_num_et = findViewById<EditText>(R.id.mobile_num_et)
        val gst_num_et = findViewById<EditText>(R.id.gst_num_et)
        val Tax_et = findViewById<EditText>(R.id.Tax_et)
        val gst_et = findViewById<EditText>(R.id.gst_et)
        mobile_gst_tv.setOnClickListener{
     if (one){
         gst_et.isVisible = false
         mobile_num_et.isVisible=false
         one=false
     }else{
         gst_et.isVisible = true
         mobile_num_et.isVisible=true
         one=true
     }

        }

        pricing_tv.setOnClickListener{
            if (one){
                card_view_cvvv.isVisible = false

                one=false
            }else{
                card_view_cvvv.isVisible = true

                one=true
            }

        }
        add_gst_tax_details_tv.setOnClickListener{
            if (one){
                gst_num_et.isVisible = false
                Tax_et.isVisible = false

                one=false
            }else{
                gst_num_et.isVisible = true
                Tax_et.isVisible = true

                one=true
            }

        }

        Add_items_btn.setOnClickListener {
            customBottomSheetDialogFragment.apply {
                show(supportFragmentManager,tag)
            }

            }
        }



    }



