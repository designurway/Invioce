package com.example.invoicekotlin

import android.os.Bundle
import android.renderscript.ScriptGroup
import android.view.LayoutInflater
import android.view.View
import android.view.View.inflate
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.example.invoicekotlin.databinding.LayoutModalBottomSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class CustomBottomSheetDialogFragment : BottomSheetDialogFragment() {
    lateinit var binding: LayoutModalBottomSheetBinding


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding  =LayoutModalBottomSheetBinding.inflate(inflater, container, false)
       return binding.root

    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        var one:Boolean=false

//      binding.morePricingTv.setOnClickListener {
//            //handle click event
//          if (one){
//              binding.cardViewCvvvv.isVisible = false
//
//              one=false
//          }else{
//              binding.cardViewCvvvv.isVisible = true
//
//              one=true
//          }
//
//            Toast.makeText(context, "First Button Clicked", Toast.LENGTH_SHORT).show()
//        }
//        binding.addMoreGstTaxDetailsTv.setOnClickListener {
//            if (one){
//              binding.gstNumEt.isVisible = false
//                binding.TaxEt.isVisible = false
//
//                one=false
//            }else{
//                binding.gstNumEt.isVisible = true
//                binding.TaxEt.isVisible = true
//
//                one=true
//            }
//            //handle click event
//            Toast.makeText(context, "Second Button Clicked", Toast.LENGTH_SHORT).show()
//        }


    }
}